package sort;

public class Code06_BSAwesome {

	public static void main(String[] args) {
		// Auto-generated method stub

	}

}
